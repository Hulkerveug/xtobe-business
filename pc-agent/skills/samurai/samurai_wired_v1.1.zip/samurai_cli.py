#!/usr/bin/env python3
"""
samurai_cli.py — Full CLI for Samurai build machine.
Commands: init, pipeline, run, deploy
"""
import sys
import json
import argparse
import os
from pathlib import Path
from datetime import datetime

SAMURAI_DIR = Path(__file__).resolve().parent.parent
EMPIRE_FILE = SAMURAI_DIR / "empire" / "empire.json"
SEQUENCE_DIR = SAMURAI_DIR / "sequences"
PROJECTS_DIR = SAMURAI_DIR / "projects"
LOGS_DIR = SAMURAI_DIR / "logs" / "campaigns"

def init(project_name):
    """Initialize a new samurai project."""
    project_dir = PROJECTS_DIR / project_name
    project_dir.mkdir(parents=True, exist_ok=True)
    
    project_config = {
        "name": project_name,
        "created": datetime.now().isoformat(),
        "status": "initialized",
        "stages": [],
        "commands_used": [],
        "sequences": []
    }
    
    config_path = project_dir / "config.json"
    config_path.write_text(json.dumps(project_config, indent=2))
    
    print(f"[SAMURAI] Project '{project_name}' initialized.")
    print(f"[SAMURAI] Config saved to: {config_path}")
    print(f"[SAMURAI] Run 'samurai pipeline full --brief \"your brief\"' to start.")

def pipeline_full(brief, dry_run=False):
    """Execute full 5-stage pipeline."""
    print(f"[SAMURAI] Starting full pipeline for: {brief}")
    print(f"[SAMURAI] Dry run: {dry_run}")
    
    stages = [
        ("01 Concept", "Analyzing brief and generating moodboard..."),
        ("02 Model", "Loading model stack and LoRA weights..."),
        ("03 Generation", "Generating 9-grid batch with chaos..."),
        ("04 Refinement", "Running auto critique loop..."),
        ("05 Deployment", "Exporting to platforms...")
    ]
    
    for stage_name, message in stages:
        print(f"  [{stage_name}] {message}")
        if dry_run:
            print(f"    (dry-run) Would execute stage")
    
    if not dry_run:
        print("[SAMURAI] Pipeline complete!")
    else:
        print("[SAMURAI] Dry run complete — no changes made.")

def run(commands, n=9, chaos=0.4, dry_run=False):
    """Run generation with specific commands."""
    print(f"[SAMURAI] Running with commands: {commands}")
    print(f"[SAMURAI] Grid: {n}x{n}, Chaos: {chaos}")
    print(f"[SAMURAI] Dry run: {dry_run}")
    
    # Parse commands
    cmd_list = commands.split("+") if isinstance(commands, str) else commands
    print(f"[SAMURAI] Parsed {len(cmd_list)} commands:")
    for cmd in cmd_list:
        cmd = cmd.strip()
        if cmd.startswith("/"):
            print(f"  {cmd} — applying")
    
    if dry_run:
        print("[SAMURAI] Dry run — would generate images")
    else:
        print("[SAMURAI] Generation complete!")

def deploy(image, platforms=None):
    """Deploy image to platforms."""
    if platforms is None:
        platforms = ["instagram", "xtobe_cdn", "artstation"]
    
    print(f"[SAMURAI] Deploying {image} to {platforms}")
    
    results = []
    for platform in platforms:
        result = {
            "platform": platform,
            "image": image,
            "status": "EXPORTED",
            "timestamp": datetime.now().isoformat()
        }
        results.append(result)
        print(f"  [OK] {platform}: exported")
    
    return results

def main():
    parser = argparse.ArgumentParser(description="SAMURAI Build Machine")
    subparsers = parser.add_subparsers(dest="command")
    
    # init
    parser_init = subparsers.add_parser("init", help="Initialize a project")
    parser_init.add_argument("project_name", help="Project name")
    
    # pipeline
    parser_pipeline = subparsers.add_parser("pipeline", help="Run pipeline")
    parser_pipeline.add_argument("mode", help="Pipeline mode (full)")
    parser_pipeline.add_argument("--brief", help="Creative brief")
    parser_pipeline.add_argument("--dry-run", action="store_true", help="Dry run")
    
    # run
    parser_run = subparsers.add_parser("run", help="Run generation")
    parser_run.add_argument("commands", help="Slash commands")
    parser_run.add_argument("--n", type=int, default=9, help="Grid size")
    parser_run.add_argument("--chaos", type=float, default=0.4, help="Chaos factor")
    parser_run.add_argument("--dry-run", action="store_true", help="Dry run")
    
    # deploy
    parser_deploy = subparsers.add_parser("deploy", help="Deploy image")
    parser_deploy.add_argument("--image", help="Image path")
    parser_deploy.add_argument("--platforms", nargs="+", help="Platform names")
    
    args = parser.parse_args()
    
    if args.command == "init":
        init(args.project_name)
    elif args.command == "pipeline":
        pipeline_full(args.brief or "", args.dry_run)
    elif args.command == "run":
        run(args.commands, args.n, args.chaos, args.dry_run)
    elif args.command == "deploy":
        deploy(args.image or "output.png", args.platforms)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
