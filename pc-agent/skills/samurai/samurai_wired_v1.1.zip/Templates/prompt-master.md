# Prompt Template

## Core Prompt
Subject: {{subject}}
Style: {{style}}
Lighting: {{lighting}}
Camera: {{camera}}
Negative: {{negative_prompt}}

## Extended Parameters
- **Aspect Ratio:** {{aspect_ratio}}
- **Resolution:** {{resolution}}
- **Seed:** {{seed}}
- **Steps:** {{steps}}
- **CFG Scale:** {{cfg_scale}}
- **Sampler:** {{sampler}}

## LoRA Stack
- **Base Model:** {{base_model}}
- **LoRA 1:** {{lora_1}} (weight: {{lora_1_weight}})
- **LoRA 2:** {{lora_2}} (weight: {{lora_2_weight}})

## Command Sequence
{{command_sequence}}

## Samurai Sequence
Soldier: {{soldier}}
Tier: {{tier}}
Sequence: {{sequence_path}}
