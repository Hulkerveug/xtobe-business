# Deployment Checklist

## Pre-Deploy
- [ ] Resolution OK
- [ ] Metadata clean
- [ ] Watermark applied
- [ ] Client proof generated
- [ ] Version control committed

## Platform Export
- [ ] Instagram: {{instagram_status}}
- [ ] Xtobe CDN: {{xtobe_cdn_status}}
- [ ] ArtStation: {{artstation_status}}
- [ ] Local archive: {{local_archive_status}}

## Post-Deploy
- [ ] Client approval received
- [ ] Changelog updated
- [ ] Archive project saved
- [ ] Review complete
