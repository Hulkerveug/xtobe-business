# Creative Brief

## Project Details
- **Client:** {{client}}
- **Project:** {{project_name}}
- **Date:** {{date}}

## Goal
{{goal}}

## Mood & Atmosphere
{{mood}}

## Style Reference
- **Primary Style:** {{primary_style}}
- **Secondary Style:** {{secondary_style}}
- **Color Palette:** {{palette}}
- **Lighting:** {{lighting}}

## Constraints
- **Resolution:** {{resolution}}
- **Aspect Ratio:** {{aspect_ratio}}
- **Negative Prompt:** {{negative}}
- **Seed:** {{seed}}
- **Model:** {{model}}
- **LoRA Stack:** {{lora_stack}}

## Samurai Commands Used
- /01-analyze: {{analysis}}
- /02-brief: {{brief}}
- /07-model: {{model_choice}}
- /12-style: {{style_preset}}
- /33-chaos: {{chaos_level}}
- /89-export: {{export_settings}}

## Revision History
1. Initial brief
2. Style applied
3. Generation complete
4. Refinement pass
5. Final delivery
