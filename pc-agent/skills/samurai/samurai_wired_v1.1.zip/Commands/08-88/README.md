# 08-88

Refinement commands: enhance, facefix, inpaint, outpaint, variation, compare, critique, psychovisual, deepdream, tile, final
