# 07-77

Effects commands: fx, particle, fluid, fire, magic, tech, glitch, motion, energy, weather-fx, destruction
