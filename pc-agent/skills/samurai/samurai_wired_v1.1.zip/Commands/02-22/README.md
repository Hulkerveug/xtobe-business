# 02-22

Style commands: style, medium, era, mood, palette, texture, stroke, film, light, reference, fusion
