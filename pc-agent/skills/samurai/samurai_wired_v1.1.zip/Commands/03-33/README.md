# 03-33

Composition commands: frame, rule, depth, focus, camera, scale, symmetry, leading, negative-space, crowd, chaos
