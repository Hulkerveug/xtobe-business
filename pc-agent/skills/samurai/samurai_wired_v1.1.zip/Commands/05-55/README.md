# 05-55

Character commands: char, face, eyes, hair, outfit, pose, expression, age, anatomy, hands, crowd-char
