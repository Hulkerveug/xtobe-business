# 02-model

Stage 02: Model — Input prompt v1, Output model stack + LoRA weights
