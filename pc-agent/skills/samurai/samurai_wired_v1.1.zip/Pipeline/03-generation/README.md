# 03-generation

Stage 03: Generation — Input model stack, Output 9-grid batch + chaos
