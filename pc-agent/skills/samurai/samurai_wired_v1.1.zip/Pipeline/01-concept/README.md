# 01-concept

Stage 01: Concept — Input brief, Output moodboard + prompt v1
