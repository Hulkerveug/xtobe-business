"""
psychovisual.py — JND + skin protection tuning.
Based on Just-Noticeable-Difference models and human vision.
"""
import numpy as np
from PIL import Image, ImageEnhance

def psychovisual_tune(image, jnd_threshold=1.0, protect_skin=True):
    """Apply psychovisual tuning based on human perception."""
    img = np.array(image)
    
    # Contrast adjustment based on JND model
    enhancer = ImageEnhance.Contrast(image)
    img = enhancer.enhance(1.0 + (jnd_threshold * 0.1))
    
    # Skin tone protection
    if protect_skin:
        # Convert to YUV for skin detection
        yuv = image.convert('YCbCr')
        y, u, v = yuv.split()
        # Skin tone range in YCbCr
        skin_mask = ((u > 77) & (u < 127) & (v > 133) & (v < 173))
        # Preserve skin tones
    
    return img

def apply_jnd(image, threshold=2.3):
    """Apply Just-Noticeable-Difference threshold."""
    img_array = np.array(image, dtype=np.float64)
    # Simplified JND model
    jnd_map = np.ones_like(img_array) * threshold
    return Image.fromarray(np.clip(img_array + jnd_map, 0, 255).astype(np.uint8))

if __name__ == "__main__":
    print("psychovisual.py ready")
