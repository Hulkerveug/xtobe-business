"""
model_loader.py — SDXL/Pony/Flux + LoRA stack loader.
Loads and manages multiple AI models and LoRA weights.
"""
import json
from pathlib import Path

class ModelLoader:
    def __init__(self):
        self.models = {}
        self.loras = {}
        self.current_model = None
        self.current_lora = None
    
    def load_model(self, name, path=None):
        """Load a base model."""
        self.models[name] = {
            'path': path,
            'loaded': False,
            'type': self._detect_type(name)
        }
        self.current_model = name
        return self.models[name]
    
    def _detect_type(self, name):
        """Detect model type from name."""
        name_lower = name.lower()
        if 'sdxl' in name_lower or 'stable-diffusion-xl' in name_lower:
            return 'sdxl'
        elif 'pony' in name_lower or 'animagine' in name_lower:
            return 'pony'
        elif 'flux' in name_lower:
            return 'flux'
        return 'unknown'
    
    def load_lora(self, name, weight=1.0, path=None):
        """Load a LoRA weight."""
        self.loras[name] = {
            'weight': weight,
            'path': path,
            'applied': False
        }
        self.current_lora = name
        return self.loras[name]
    
    def stack_loras(self, lora_list):
        """Stack multiple LoRAs with weights."""
        stacked = []
        for lora_name, weight in lora_list:
            if lora_name in self.loras:
                stacked.append((lora_name, weight))
        return stacked
    
    def get_config(self):
        """Get current model configuration."""
        return {
            'model': self.current_model,
            'model_type': self.models.get(self.current_model, {}).get('type', 'unknown'),
            'lora': self.current_lora,
            'lora_weight': self.loras.get(self.current_lora, {}).get('weight', 1.0),
            'loras': {k: v['weight'] for k, v in self.loras.items()}
        }

if __name__ == "__main__":
    loader = ModelLoader()
    print("model_loader.py ready")
