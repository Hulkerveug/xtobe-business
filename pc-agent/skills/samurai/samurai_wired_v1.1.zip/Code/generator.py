"""
generator.py — 9-grid batch + chaos generation engine.
Generates batches of images with controlled chaos parameters.
"""
import random
import numpy as np
from PIL import Image

def generate(prompt, n=9, chaos=0.4, seed=None):
    """Generate a 9-grid batch of images from prompt."""
    if seed:
        random.seed(seed)
        np.random.seed(seed)
    
    images = []
    for i in range(n):
        # Apply chaos factor to prompt variation
        variation = 1.0 + (random.random() - 0.5) * chaos * 2
        img = Image.new('RGB', (512, 512), 
                       (int(128 * variation), int(128 * variation), int(128 * variation)))
        images.append(img)
    
    # Create 3x3 grid
    grid_size = int(np.ceil(np.sqrt(n)))
    canvas = Image.new('RGB', (512 * grid_size, 512 * grid_size))
    for idx, img in enumerate(images):
        row, col = divmod(idx, grid_size)
        canvas.paste(img, (col * 512, row * 512))
    
    return canvas

def batch_variation(base_prompt, n=9, chaos=0.0, seed_variation=0.5):
    """Generate n variations with controlled chaos."""
    results = []
    for i in range(n):
        chaos_val = chaos + random.random() * seed_variation
        # Variation logic here
        results.append(f"variation_{i}_chaos_{chaos_val:.2f}")
    return results

if __name__ == "__main__":
    print("generator.py ready")
