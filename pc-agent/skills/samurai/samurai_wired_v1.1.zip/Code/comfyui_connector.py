"""
comfyui_connector.py — Queues workflow JSON, polls /history, supports websocket.
Communicates with ComfyUI server via REST API.
"""
import json
import urllib.request
import urllib.error
import time
import threading
from pathlib import Path
from datetime import datetime

class ComfyUIConnector:
    def __init__(self, base_url="http://127.0.0.1:8188"):
        self.base_url = base_url.rstrip("/")
        .prompt_endpoint = f"{self.base_url}/prompt"
        self.history_endpoint = f"{self.base_url}/history"
        self.queue_endpoint = f"{self.base_url}/queue"
        self.ws_endpoint = f"ws://{self.base_url}/ws"
    
    def check_connection(self):
        """Verify ComfyUI server is reachable."""
        try:
            req = urllib.request.Request(f"{self.base_url}/system_stats")
            with urllib.request.urlopen(req, timeout=5) as resp:
                return True, json.loads(resp.read())
        except Exception as e:
            return False, {"error": str(e)}
    
    def queue_prompt(self, workflow):
        """Queue a ComfyUI workflow JSON."""
        payload = {"prompt": workflow}
        try:
            req = urllib.request.Request(
                self.prompt_endpoint,
                data=json.dumps(payload).encode(),
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.loads(resp.read())
                return result
        except urllib.error.URLError as e:
            return {"error": f"ComfyUI queue failed: {e}"}
    
    def queue_and_wait(self, workflow, max_wait=300):
        """Queue prompt and wait for completion."""
        result = self.queue_prompt(workflow)
        if "error" in result:
            return result
        
        prompt_id = result.get("prompt_id")
        if not prompt_id:
            return {"error": "No prompt_id returned"}
        
        # Poll for completion
        start = time.time()
        while time.time() - start < max_wait:
            history = self.get_history(prompt_id)
            if history and prompt_id in history:
                return history[prompt_id]
            time.sleep(2)
        
        return {"error": "Timeout waiting for generation"}
    
    def get_history(self, prompt_id=None):
        """Get generation history."""
        url = self.history_endpoint
        if prompt_id:
            url += f"/{prompt_id}"
        try:
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read())
        except Exception as e:
            return {"error": str(e)}
    
    def load_workflow(self, workflow_path):
        """Load a ComfyUI workflow JSON file."""
        path = Path(workflow_path)
        if not path.exists():
            return {"error": f"Workflow not found: {workflow_path}"}
        return json.loads(path.read_text())
    
    def generate_with_workflow(self, workflow_path, overwrite_inputs=None):
        """Generate using a workflow file with optional input overrides."""
        workflow = self.load_workflow(workflow_path)
        if "error" in workflow:
            return workflow
        
        # Override inputs if provided
        if overwrite_inputs:
            workflow = self._override_inputs(workflow, overwrite_inputs)
        
        return self.queue_and_wait(workflow)
    
    def _override_inputs(self, workflow, overrides):
        """Override specific node inputs in the workflow."""
        for node_id, node in workflow.get("nodes", {}).items():
            if node.get("class_type") == "KSampler":
                if "seed" in overrides:
                    node["inputs"]["seed"] = overrides["seed"]
                if "steps" in overrides:
                    node["inputs"]["steps"] = overrides["steps"]
                if "cfg" in overrides:
                    node["inputs"]["cfg"] = overrides["cfg"]
            if node.get("class_type") == "CLIPTextEncode":
                if "text" in overrides:
                    node["inputs"]["text"] = overrides["text"]
        return workflow
    
    def create_workflow_json(self, model, prompt, **kwargs):
        """Create a basic ComfyUI workflow JSON."""
        workflow = {
            "3": {
                "class_type": "KSampler",
                "inputs": {
                    "seed": kwargs.get("seed", 42),
                    "steps": kwargs.get("steps", 30),
                    "cfg": kwargs.get("cfg", 7),
                    "sampler_name": kwargs.get("sampler", "euler"),
                    "scheduler": "normal",
                    "denoise": 1.0,
                    "model": ["4", 0],
                    "positive": ["6", 0],
                    "negative": ["7", 0],
                    "latent_image": ["5", 0]
                }
            },
            "4": {
                "class_type": "CheckpointLoaderSimple",
                "inputs": {"checkpoint_name": model}
            },
            "6": {
                "class_type": "CLIPTextEncode",
                "inputs": {"text": prompt, "clip": ["4", 1]}
            },
            "7": {
                "class_type": "CLIPTextEncode",
                "inputs": {"text": kwargs.get("negative", ""), "clip": ["4", 1]}
            },
            "5": {
                "class_type": "EmptyLatentImage",
                "inputs": {
                    "width": kwargs.get("width", 512),
                    "height": kwargs.get("height", 512),
                    "batch_size": kwargs.get("batch_size", 1)
                }
            },
            "8": {
                "class_type": "VAEDecode",
                "inputs": {"pixels": ["3", 0], "vae": ["4", 2]}
            },
            "9": {
                "class_type": "SaveImage",
                "inputs": {"images": ["8", 0]}
            }
        }
        return workflow

if __name__ == "__main__":
    conn = ComfyUIConnector()
    ok, info = conn.check_connection()
    if ok:
        print(f"[ComfyUI] Connected to {conn.base_url}")
    else:
        print(f"[ComfyUI] Server not found at {conn.base_url}")
        print("[ComfyUI] Start with: python main.py --listen")
