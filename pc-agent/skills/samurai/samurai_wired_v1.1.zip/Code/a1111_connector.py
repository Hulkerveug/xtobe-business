"""
a1111_connector.py — Full A1111 API bridge with LoRA injection.
Supports <lora:name:weight> syntax, batch 9 with chaos seeds.
"""
import json
import urllib.request
import urllib.error
import time
from pathlib import Path
from datetime import datetime

class A1111Connector:
    def __init__(self, base_url="http://127.0.0.1:7860"):
        self.base_url = base_url.rstrip("/")
        self.generate_url = f"{self.base_url}/sdapi/v1/txt2img"
        self.img2img_url = f"{self.base_url}/sdapi/v1/img2img"
        self.options_url = f"{self.base_url}/sdapi/v1/options"
        self.models_url = f"{self.base_url}/sdapi/v1/loras"
    
    def check_connection(self):
        """Verify A1111 server is reachable."""
        try:
            req = urllib.request.Request(f"{self.base_url}/sdapi/v1/version")
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read())
                return True, data
        except Exception as e:
            return False, {"error": str(e)}
    
    def generate(self, prompt, negative_prompt="", **kwargs):
        """Generate image via A1111 txt2img API."""
        payload = {
            "prompt": prompt,
            "negative_prompt": negative_prompt,
            "steps": kwargs.get("steps", 30),
            "cfg_scale": kwargs.get("cfg_scale", 7),
            "sampler_name": kwargs.get("sampler", "Euler a"),
            "width": kwargs.get("width", 512),
            "height": kwargs.get("height", 512),
            "seed": kwargs.get("seed", -1),
            "batch_size": kwargs.get("batch_size", 1),
            "n_iter": kwargs.get("n_iter", 1),
            "override_settings": kwargs.get("override_settings", {})
        }
        
        try:
            req = urllib.request.Request(
                self.generate_url,
                data=json.dumps(payload).encode(),
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=kwargs.get("timeout", 120)) as resp:
                result = json.loads(resp.read())
                return result
        except urllib.error.URLError as e:
            return {"error": f"A1111 connection failed: {e}"}
    
    def generate_batch(self, prompt, n=9, chaos=0.4, **kwargs):
        """Generate 9-grid batch with chaos seeds."""
        results = []
        for i in range(n):
            seed = kwargs.get("seed", -1)
            if seed == -1:
                seed = int(time.time() * 1000) + int(chaos * 10000) + i
            
            result = self.generate(
                prompt=prompt,
                seed=seed,
                steps=kwargs.get("steps", 30),
                cfg_scale=kwargs.get("cfg_scale", 7),
                sampler=kwargs.get("sampler", "Euler a")
            )
            result["index"] = i
            result["seed"] = seed
            result["chaos"] = chaos
            results.append(result)
            time.sleep(0.5)  # Rate limiting
        
        return {"batch": results, "total": len(results)}
    
    def inject_lora(self, lora_name, weight=1.0):
        """Generate LoRA injection prompt syntax: <lora:name:weight>"""
        if weight == 1.0:
            return f"<lora:{lora_name}:1>"
        return f"<lora:{lora_name}:{weight}>"
    
    def build_prompt_with_loras(self, base_prompt, lora_stack):
        """Build prompt with LoRA injection tags."""
        prompt = base_prompt
        for lora_name, weight in lora_stack:
            prompt += f" {self.inject_lora(lora_name, weight)}"
        return prompt.strip()
    
    def get_models(self):
        """List available models."""
        try:
            req = urllib.request.Request(f"{self.options_url}")
            with urllib.request.urlopen(req, timeout=5) as resp:
                return json.loads(resp.read())
        except:
            return {"error": "Cannot fetch models"}

if __name__ == "__main__":
    conn = A1111Connector()
    ok, info = conn.check_connection()
    if ok:
        print(f"[A1111] Connected to {conn.base_url}")
        print(f"[A1111] Server info: {json.dumps(info, indent=2)}")
    else:
        print(f"[A1111] Server not found at {conn.base_url}")
        print("[A1111] Start with: python launch.py --api")
