"""
deepdream.py — Torch + OpenCV fallback deepdream engine.
Amplifies patterns detected by convolutional neural networks.
"""
import torch
import torchvision.models as models
import torchvision.transforms as transforms
from PIL import Image
import numpy as np

def deepdream(image_path, iterations=100, step_size=0.01, layers=None):
    """Apply DeepDream to an image."""
    if layers is None:
        layers = ['layer4']
    
    img = Image.open(image_path).convert('RGB')
    preprocess = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    
    img_tensor = preprocess(img).unsqueeze(0)
    img_tensor.requires_grad_(True)
    
    model = models.vgg19(pretrained=True).features.eval()
    
    for i in range(iterations):
        output = model(img_tensor)
        loss = output.norm()
        model.zero_grad()
        loss.backward()
        
        with torch.no_grad():
            img_tensor += step_size * img_tensor.grad.sign()
        
        if i % 10 == 0:
            print(f"DeepDream iteration {i}/{iterations}, loss: {loss.item():.4f}")
    
    return img_tensor.squeeze(0).detach()

if __name__ == "__main__":
    print("deepdream.py ready")
