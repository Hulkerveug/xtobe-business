# SAMURAI — Full Build v2.0

**Location:** `C:\Users\Nishan\Xtobe\Skills\samurai\`
**Version:** 2.0.0 | **Lines:** 222 (SKILL.md) | **Size:** 12KB+
**Author:** Nishan Ramanathan

## Status: DONE. ALL INBUILT.

| Component | Status |
|---|---|
| **SKILL.md** | **222 lines** — full 99 commands + 5-stage pipeline |
| **Commands/** | 9 folders 01-11 to 09-99 with READMEs |
| **Pipeline/** | 5 stages Concept→Deploy |
| **Code/** | 6 working Python modules |
| **Templates/** | 3 production templates |
| **CLI** | `samurai_cli.py` + `samurai.bat` Windows launcher |

## Quick Start

```bash
# Windows
C:\Users\Nishan\Xtobe\Skills\samurai\samurai.bat init my_project

# Or via Python
python samurai_cli.py pipeline full --brief "ronin in neo-kyoto rain"
python samurai_cli.py run "/68-particle sakura 500" --n 9 --chaos 0.4
python samurai_cli.py deploy --image hero_refined.jpg
```

## Structure

```
samurai/
├── SKILL.md              ← Master skill (222 lines)
├── samurai_cli.py        ← Full CLI
├── samurai.bat           ← Windows launcher
├── Commands/             ← 9 command folders with READMEs
│   ├── 01-11/
│   ├── 02-22/
│   ├── 03-33/
│   ├── 04-44/
│   ├── 05-55/
│   ├── 06-66/
│   ├── 07-77/
│   ├── 08-88/
│   └── 09-99/
├── Pipeline/             ← 5 stage folders
│   ├── 01-concept/
│   ├── 02-model/
│   ├── 03-generation/
│   ├── 04-refinement/
│   └── 05-deployment/
├── Code/                 ← 6 Python modules
│   ├── deepdream.py
│   ├── psychovisual.py
│   ├── generator.py
│   ├── model_loader.py
│   ├── refine_pipeline.py
│   └── deploy.py
├── Templates/            ← 3 production templates
│   ├── creative-brief.md
│   ├── deployment-checklist.md
│   └── prompt-master.md
└── sequences/            ← 10 soldier JSON files
```

## 99 Commands Summary

**[01-11]** Foundation — analyze, brief, keywords, model, lora, sampler, upscale
**[12-22]** Style — style, medium, era, mood, palette, texture, film, light
**[23-33]** Composition — frame, rule, depth, focus, camera, chaos, symmetry
**[24-44]** Lighting — keylight, fill, rim, volumetric, hdr, weather, studio
**[45-55]** Character — char, face, eyes, hair, pose, expression, anatomy
**[56-66]** Worldbuild — env, arch, nature, city, terrain, lore, culture
**[67-77]** Effects — fx, particle, fluid, fire, magic, glitch, destruction
**[78-88]** Refinement — enhance, facefix, inpaint, critique, deepdream, final
**[89-99]** Deployment — export, watermark, optimize, deploy, archive, seppuku

## Safety
- Dry-run is DEFAULT — nothing executes without --apply
- Hash-chain audit on every step
- Network fetch forbidden
- Local machine only

## License
MIT — Built for Nishan Ramanathan
